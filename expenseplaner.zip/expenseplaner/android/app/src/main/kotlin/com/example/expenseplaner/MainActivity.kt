package com.example.expenseplaner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
